
setwd("C:\Users\User\Documents\NetBeansProjects\chatbot\web")
#q<-"writing is done again again again again"
#write.csv(q,file="C:\\Users\\areeba\\Desktop\\writing.csv",row.names = F) 

library(readxl)
library(data.table)
library(Runiversal)
library(RTextTools)
#q<-"writing is done again again again again"
#write.csv(q,file="C:\\Users\\areeba\\Desktop\\writing.csv",row.names = F)

test<-read_excel(("C:\\Users\\User\\Desktop\\testing.xlsx"))#QUERY FILE
#View(test)
svm<-function(test)
{
  dtMatrix <- create_matrix(test_admit["type"])
  #View(dtMatrix)
container <- create_container(dtMatrix,test_admit$catogory,trainSize =1:1215,virgin=FALSE)
  #View(container)
svm_model <-  train_model(container,"SVM",kernel = "radial",cost=1)
predictionData<-test
  #View(predictionData)
predMatrix<-create_matrix(predictionData, originalMatrix=dtMatrix)
#View(predMatrix)
 #trace("create_matrix",edit = T)
predSize = length(predictionData)
  #View(predSize)
predictionContainer<-create_container(predMatrix, labels=rep(0,predSize), testSize=1:predSize, virgin=FALSE)
  #View(predictionContainer)
results <-  classify_model(predictionContainer, svm_model)
results
match<-results[,"SVM_LABEL"]
#match("")
answers <- read_excel("C:\\Users\\User\\Desktop\\answer.xlsx", header = T)#ANSWERS FILE
#answers
matches <- answers[grep(paste(match, collapse="|"), answers$catogory), ]
  #matches
library(tibble)
matches_tibble<-as_tibble(matches)
    # matches_tibble
name<-matches_tibble[,"answer"]
 name
return(write.table(name,file="C:\\Users\\User\\Desktop\\output.xlsx",row.names = F,col.names=F))}

